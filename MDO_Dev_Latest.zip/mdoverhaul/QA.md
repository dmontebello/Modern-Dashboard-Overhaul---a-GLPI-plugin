# QA — Modern Dashboard Overhaul 0.8.1-dev.7 (Dev)

Stato corrente: NON COLLAUDATO LIVE. Gli esiti e ambienti precedenti sotto restano storici.

**Ambiente:** codice della 0.6.0 Documented Pilot verificato con SHA-512; modifiche 0.7.0 analizzate ed eseguite offline. **Non è un test end-to-end della GLPI di produzione.**

| Controllo | Evidenza 0.7.0 |
| --- | --- |
| UI Chromium headless | **80 test superati** su 1440, 1024, 780 e 390 px, widget KPI, RSS, temi, filtri, oltre 40 tab, `+`, edit, ECharts con caricamento asincrono |
| PHP isolato | **38 test superati** su configurazioni, memoizzazione, hook, ACL con mock, sanitizer RSS, date, 4 preset e chiavi legacy |
| Performance | Benchmark locale 62 grafici: timer di retry **186 (0.6) → 3 (0.7)**; 250 mutazioni numero danno un singolo refresh in fixture |
| Controlli sintassi | `php -l` per tutti i PHP, `node --check` JavaScript, `bash -n` per gli script |
| Integrità | SHA-512 della 0.6 verificato prima dell'editing; manifest e ZIP 0.7 rigenerati e ricontrollati |
| Sicurezza | Test URL per schemi non sicuri/credenziali, escaping RSS, accesso feed in profili mock differenti, form allowlist con rifiuto input incompleti |
| Dipendenze | Nessun framework aggiuntivo, font esterno, telemetria, chiamata AJAX aggiuntiva o schema DB introdotto |

## Limiti delle verifiche

- Chromium usa una **fixture HTML che riproduce classi/markup principali di GLPI 11.0.9**, non GLPI reale. Screenshot nel processo di build non vengono inclusi nel plugin per evitare dati privati.
- Alcuni grafici della fixture sono simulati; ECharts viene testato tramite istanza mock. Grafici effettivi e GridStack su GLPI richiedono test visivo e funzionale sulla VM.
- Le ACL mock verificano che il codice controlli i permessi, **non dimostrano l'esattezza delle ACL di tutte le installazioni GLPI**.
- Il benchmark confronta la **quantità di retry pianificati** e non misura prestazioni browser in condizioni di carico reale né memoria Apache/PHP.
- **Le due CVE del runtime PHP 2026 non sono correggibili all'interno del plugin.** Verificare la patch effettivamente in esecuzione in Apache/PHP-FPM.

## Collaudo necessario sulla VM prima di accettare la 0.7

1. GLPI 11.0.9: admin → Configura, modifica e salva le sette opzioni; utente senza `config:UPDATE` deve essere respinto.
2. Verificare i feed RSS privati/pubblici con profili, entità e gruppi differenti (nessuna fuga dati).
3. Dashboard in entrambe le modalità, widget da piccoli a grandi, browser desktop/mobile reali, zoom 125/150%.
4. Creare, rinominare, clonare ed eliminare dashboard con tab e `+`; entrare/uscire da modifica, spostare widget GridStack.
5. Collaudare il caricamento RSS (5/10/15/20), feed vuoto/offline, contenuto ostile, date, scrolling, nessun collegamento JavaScript.
6. Testare modulo Restyling OFF + RSS ON e viceversa. **Non salvare dashboard in modifica con RSS disabilitato**.
7. Confrontare registri Apache/PHP/GLPI e tempo/carico con dashboard equivalenti su 0.6/0.7.
8. Ripristino versione 0.6 dalla copia, su sistema di prova. Confermare backup di database/volumi.

I criteri generali sono in [TEST_MATRIX](docs/TEST_MATRIX.md). **Non dichiarare stabile 1.0 senza questi test**.

## 0.8.0 — Verifiche preliminari

Modificati i test PHP isolati per sette impostazioni e il menu condizionale. Da eseguire su GLPI 11 reale: abilitazione/disabilitazione opzioni, cache sessione menu, lista nativa ProjectTask, restrizioni per entità e team, board di sola lettura, Kanban Vue drag/drop, dark/light, mobile. Nessun test end-to-end sulla tua installazione è stato ancora eseguito.

## 0.8.0 — Pacchetto unico

MDO 0.8.0 contiene dashboard/RSS precedenti e task/kanban nella stessa directory installabile. Verifiche richieste: sintassi PHP/JS, test unit isolati, SHA512SUMS di sorgenti e ZIP, corretta radice `mdoverhaul/`, assenza di patch/vecchi ZIP annidati. **Il collaudo sul GLPI operativo è ancora da effettuare**; i risultati storici 0.7 non sono prova end-to-end della 0.8.

## Tasks P0/P1 — verifica locale del 2026-10-24, non pubblicata

Baseline `Dev`: `dd275eb`. Runtime PHP 8.4.27, Git 2.52.0, Node e Chromium
locali, Playwright 1.62.0. Nessuna istanza GLPI o database applicativo collegato.

| Verifica eseguita | Esito e limite |
| --- | --- |
| `php tests/unit_php.php` | PASS, 67 controlli moduli/RSS e matrice flag/diritti |
| `php tests/tasks_php.php` | PASS, 59 controlli Tasks; doubles GLPI isolati |
| `bash tools/verifica-sintassi.sh --local` | PASS, 15 PHP / 6 Bash / 2 JS |
| Python modificati e YAML Actions | Parsing sintattico locale |
| `python3 tests/ui_playwright.py` | PASS, 80 controlli della dashboard su DOM simulato |
| `python3 tests/tasks_ui_playwright.py` | PASS, 167 controlli del controller reale con doubles e CSS GLPI rappresentativo |
| Responsive Tasks | 1440/1024/768/390 px, light/dark, 0/100 task, titoli lunghi, keyboard e form GET |
| Skin Kanban | Scope/geometria e attributi nativi su fixture; Vue/DnD reale NON TESTATO |
| Build locale `package_from_repo.py --output …` | Unico ZIP completo `mdoverhaul/`, versione 0.8.0; checksum/integrità verificati per la consegna |
| GitHub Actions remota | NON ESEGUITA per questi commit locali; workflow aggiornata |

Gli screenshot locali desktop/mobile del controller sono stati ispezionati.
Il primo avvio Chromium nella sandbox è stato impedito dai socket; lo stesso
test è stato poi eseguito con successo nel contesto di esecuzione autorizzato.
Anche il fetch iniziale richiedeva quel contesto; il vero HEAD Dev è stato letto.

Il pacchetto è un artefatto locale di revisione: non sostituisce lo ZIP 0.8.0
pubblicato. Nessun push, merge, release o deployment. I collaudi GLPI reali e le
decisioni strutturali restano elencati nel
[rapporto Tasks](docs/specs/TASKS_IMPLEMENTATION.md) e nelle
[decisioni aperte](docs/specs/TASKS_OPEN_DECISIONS.md).



## Feedback reale GLPI — 2026-10-24 (non superato)

Il cliente osserva: contrasto scuro dei dettagli nelle opzioni Settings; selettore Project di Nuova task e pulsanti adiacenti; "Continua" che non raggiunge il form nativo; persistenti problemi di mini KPI Ticket, toolbar e legenda ECharts. Richieste nuove Task indipendenti e versione Dev visibile.

La pipeline #40074660688 e verde: 67 PHP, 61 Tasks PHP, 84 UI Dashboard, 167 UI Tasks, soltanto **doubles e DOM fixture**. Non prova il flusso di creazione con Ajax GLPI o i layout reali. Nessuno dei bug sopra puo essere marcato risolto sullo staging. Riferimenti: [specifica 0.8.1](docs/specs/MDO_0_8_1_DEV_WORKPLAN.md), [registro stato](docs/dev/STATUS.md).


## Candidata 0.8.1-dev.1

IMPLEMENTATO / test automatici: 67 PHP moduli, 63 Tasks, 8 packaging, 86 UI dashboard, 175 UI Tasks, 512 UI Settings; sintassi 18 PHP/6 Bash/2 JS e parsing Python/YAML. Build ZIP e manifest verificati. NON COLLAUDATO LIVE:
nessun accesso allo staging GLPI 11.0.9, confermato dall'utente. I bug segnalati
non sono dichiarati risolti sul GLPI reale. Comandi e limiti nelle
[note di versione](docs/releases/0.8.1-dev.1.md); risultati CI del preciso SHA
codice nel record generato docs/releases/0.8.1-dev.1.build.json dopo pubblicazione.


## Candidata 0.8.1-dev.2

IMPLEMENTATO e TESTATO CON DOUBLES. NON COLLAUDATO LIVE: nessuna istanza GLPI
11.0.9 raggiungibile, nessuna migrazione DB reale eseguita.

| Verifica locale eseguita | Esito |
| --- | --- |
| Sintassi PHP/Bash/JS | PASS: 26 PHP, 7 Bash, 2 JS |
| Parser Python e workflow YAML | PASS |
| Moduli/RSS PHP | PASS: 67 |
| Tasks/ProjectTask PHP | PASS: 63 |
| Standalone PHP | PASS: 59 |
| Packaging/provenienza/tamper | PASS: 8 |
| Browser dashboard | PASS: 86, DOM/ECharts fixture |
| Browser Tasks | PASS: 175, controller e doubles |
| Browser Settings | PASS: 560, otto switch, contrasto AA e zoom |
| Browser standalone | PASS: 108, CRUD HTTP e persistenza simulata, form responsive/zoom |
| Gate documenti e build ZIP/manifest | PASS, build locale marcata dirty senza SHA fittizio |
| DB migration/backup/restore e GLPI live | NON ESEGUITO |

Comandi nelle [note](docs/releases/0.8.1-dev.2.md). Dopo commit, la CI ripete
le prove sullo SHA esatto e genera il pacchetto pulito; record definitivo in
`docs/releases/0.8.1-dev.2.build.json`. Nessun risultato locale simula una CI verde.

Prove aggiunte: ACL owner/assignee/gruppi/entità/ricorsività/READMY/READALL,
parametri ostili e XSS, CRUD, cestino/restore/purge vietato, CSRF tramite middleware
double, modulo/plugin OFF, diritti iniziali zero, install/reinstall idempotente
con schema simulato e nessun INSERT Project/ProjectTask. I test UI usano gli
stessi controller con stato persistente simulato, non il database/Select2 GLPI.

Da collaudare: migrazione e backup/restore veri; scheda diritti Profile, login,
Search/AJAX/export/API, User/Group dropdown, diritti effettivi, geometria GridStack,
ECharts ticket_status, cache HTTP, DnD nativo e temi reali. Nessun bug live chiuso.

## 0.8.1-dev.3 — diagnosi 25 ottobre 2026

Bug ProjectTask: GLPI 11.0.9 implementa Html::redirect() lanciando RedirectException. MDO dev.2 catturava l'eccezione con catch(Throwable) e restava sulla schermata di scelta progetto. Fix: redirect fuori dal catch; nuova regressione nei test PHP che simula l'eccezione reale. CI e checksum da verificare dopo commit. **NON COLLAUDATO LIVE**: Select2, diritti, form e Salva richiedono staging. Le altre regressioni UI e migrazione/ACL standalone sono ancora da collaudare.

## Aggiornamento 0.8.1-dev.4 (25 ottobre 2026)

0.8.1-dev.4: test previsto per Dropdown::showFromArray(display=false), restituzione HTML e selezione Stato; regressioni su publisher solo documenti rispetto a modifiche sorgente senza bump; CI da verificare su SHA effettivo. NON COLLAUDATO LIVE: ricerca AJAX, Search/ACL e CRUD standalone, mini Ticket, toolbar, legenda e Settings sul GLPI reale.

## Aggiornamento 0.8.1-dev.5

Bug verificato prima del fix: log GLPI 11.0.9 con MySQL 1054 ORDER BY DESC sul Kanban ProjectTask e screenshot di accesso Standalone negato. Nella dev.5 sono corretti tre ORDER e aggiunti test sulla sintassi DB e sul testo amministrativo. Permessi non modificati: READMY/READALL vanno conferiti dal profilo. I risultati della CI non sono anticipati come PASS; il collaudo GLPI reale dopo il fix rimane NON ESEGUITO.

**CI #40189803646 (primo run dev.5): FAIL del test Tasks sulla board vuota in inglese per fixture reinizializzata dai nuovi casi ACL; gli assert SQL e ACL aggiunti risultavano già PASS. Il test è stato corretto ripristinando l'insieme vuoto subito prima dell'assert; secondo run ancora da verificare. Nessuna ZIP dev.5 pubblicata dal run fallito.**

## Consuntivo verificato 0.8.1-dev.5 — GitHub Actions 40189878021

PASS: 67 PHP, 69 Tasks, 62 Standalone, 9 packaging, 86 UI dashboard, 175 UI Tasks, 560 UI Settings e 108 UI Standalone. Archivio, SHA512SUMS, sidecar, manifest e provenienza `60fb656aad0400a31788bf68760edf390961f166` PASS. ZIP checksum `f12a4c5b7a0c13daadc6ccff60a85b83a2e3a2dfa8571d26a6d9265d9a875b206eff10577fc3674e9e57abe24176bbe7ae1e0b4624d623ec466e7a3b97475ef5`. Primo CI fallito su test fixture, corretto e ripetuto: run finale verde. **NON COLLAUDATO LIVE dopo il fix**: nuova board Project/Standalone e configurazione dei diritti nell'istanza utente. Non attribuire a questi mock una validazione delle ACL in GLPI 11.0.9 reale.


## QA 0.8.1-dev.6 — stato corrente

Verifiche CI sperimentali PHP/JS e suite browser isolate nella workflow `dev6-validation.yml`: consultare esiti per source SHA nella PR Draft #3; non equivale a un collaudo GLPI reale. Nuovo test `tests/task_activity_php.php` controlla 25 note con paginazione, protezioni READMY, allegati, Stage e conflitti. **NON COLLAUDATO LIVE**: schema 2, scrittura/drag, note e allegati, profili diversi e upload/download nel container reale. Non promuovere Main senza prove e backup/restore.


## CI finale 0.8.1-dev.6 — fonte verificata

GitHub Actions #40225944788: bundle PASS, publish_dev_zip PASS sul source SHA `080532ab6c6e5774e5445ddd80dec0c938e43726`. PHP: 67 unit, 69 Tasks, 62 Standalone, 44 Task Activity. Chromium: 86 Dashboard, 175 Tasks, 560 Settings, 108 Standalone. Passati sintassi, verifiche documentazione, packaging, checksum e provenienza. Doppio/mocks e Chromium fixture NON EQUIVALGONO al collaudo server GLPI. Restano NON COLLAUDATI LIVE: upgrade schema1→2, backup DB+file, csrf delle nuove route, DnD concorrenza, upload e download, entità e profili. ZIP e checksum in docs/releases/0.8.1-dev.6.build.json; Main invariato.


## QA dev.7

Test dedicato `tests/task_creation_php.php`: input comuni, due modalità di creazione, validazione progetto e data, permessi separati, prevenzione SQL/core bypass, CSRF middleware simulato, redirect ed errori con mantenimento valori. Gli esiti definitivi sono nel run CI del source SHA pubblicato. **NON COLLAUDATO LIVE**: Select2 AJAX, scrittura nativa sul core, profili, entità e timezone della vera installazione GLPI 11.0.9.


## Consuntivo 0.8.1-dev.7 — pubblicazione verificata, 25 ottobre 2026

**MDO-TASK-007 IN COLLAUDO OPERATIVO; NON COLLAUDATO LIVE.** Build GitHub Actions [#40236015750](https://github.com/dmontebello/Modern-Dashboard-Overhaul---a-GLPI-plugin/actions/runs/40236015750): bundle PASS, publish_dev_zip PASS; source SHA `6aa2654fa81d6e65be4184256d06a81d66603753`, compilazione UTC 2026-10-25T21:34:49Z; archivio immutabile `Modern_Dashboard_Overhaul_0.8.1-dev.7.zip`; SHA512 `4d45752f6c40907adeea3ee40ee2e8c631b965231717aefce0945eba821fd8def701ad0786ffc3897be4d630c24160f05651f3a211e5e9e664081d19c3e2b2c3`. Metadati in [note release dev.7](docs/releases/0.8.1-dev.7.md) (metadata JSON sul branch Dev, non incluso nella ZIP). Test automatici: 67 unit PHP, 69 Tasks, 62 Standalone, 44 Task Activity, 26 creazione unificata; Chromium 86 Dashboard, 175 Tasks, 72 nuova task, 560 Settings, 108 Standalone. 9 test packaging. **Prima pipeline ufficiale fallita solo sul gate documentale UPDATE.md privo della versione dev.7; aggiunta nota, nuovo test di non-scrittura su ACL negato e CI finale verde.** Non confondere mock con salvataggio o permessi reali GLPI 11.0.9. Next steps: backup DB+plugin+GLPI_DOC_DIR, staging test nuovo form con progetto/indipendente, READMY/entità, CSRF, Select2, scadenza, verifica unicità inserimento. `Main` e produzione invariati; prossima feature prevista dev.8 checklist.


## QA 0.8.1-dev.8

Feedback live: primo drag funziona, secondo drag non funziona senza reload. Bug attribuito al riutilizzo del token consumato dal middleware GLPI11; fix proposto server+client. Validare 3+ drag consecutivi, drag ghost, drop target, aggiornamento progresso e contatori; eliminazione autorizzata e negata, no purge, entità, CSRF/retry e conferma. Fixture: `tests/task_ux_php.php`, `tests/task_ux_ui_playwright.py`. **TEST LIVE DOPO FIX NON ESEGUITO**.


## QA 0.8.1-dev.9

Segnalazione LIVE dev.8: Project mostra soltanto Processing; All DnD non funziona; header count resta 2/1 fino a refresh; Independent già mostra tutte le colonne. Fix proposto: catalogo ProjectState nativo + colonne vuote, mixed sempre tre stage, API stage nativo per Project, aggiornamento contatori immediato. PHP/Chromium in fixture da verificare via CI. **NON COLLAUDATO LIVE** dopo il fix.

## Consuntivo 0.8.1-dev.9 — 26 ottobre 2026

**PUBBLICATA SU Dev, NON COLLAUDATA LIVE.** [GitHub Actions #40306267311](https://github.com/dmontebello/Modern-Dashboard-Overhaul---a-GLPI-plugin/actions/runs/40306267311): `bundle` PASS e `publish_dev_zip` PASS. Source SHA `0c6e810711a2c08c7a111573b57b516a27c4065d`, ZIP `Modern_Dashboard_Overhaul_0.8.1-dev.9.zip`, manifest e sidecar SHA512 `6ada5ce06f3bb97db1fed21d24a0cc3e1fed7a3d2722f37750819876abb018077315c90c96670af300589ebc84621cb1ab75f694191f0c1454ba851a97148658`. Provenienza completa in `docs/releases/0.8.1-dev.9.build.json` (build UTC 2026-10-26T10:19:10Z). Suite PHP: 67 unit, 72 Tasks, 62 Standalone, 48 Activity, 26 creazione e 11 UX delete. Chromium: 86 Dashboard, 175 Tasks, test DnD ripetuto e mixed All per due sorgenti, 72 form, 560 Settings e 108 Standalone. Tutto su GLPI doubles e Chromium fixture, NON equivalenti al backend reale.

**MDO-TASK-016/017/018: IN COLLAUDO OPERATIVO**: colonne ProjectState compresi stati vuoti, drag nella vista All per Project/Independent, contatori immediati. Prove LIVE ancora aperte: Project con sola task Processing mostra altri stati a 0; DnD stesso elemento ripetuto in Project/Independent/All; 2 TODO e 1 Processing -> 1 TODO e 2 Processing senza refresh; DB/persistenza/ACL/CSRF; verificare auto_projectstates impostato a 0 su spostamento nativo. Stato dopo il fix NON CHIUSO. Main 0.8.0 invariato, niente deploy automatico, nessuna migrazione DB rispetto a dev.8. Checklist e conversioni rimangono in backlog.



## QA 0.8.1-dev.10 — feedback GLPI

Utente con dev.9: Project Kanban mostra percentuali e non stati; solo Independent trascinabili; vuole card stile Notion (~260×78) e All→Kanban default. Root cause nel default group=progress e nella guardia auto_percent_done; implementata mappatura ProjectState core configurata, senza modifiche alla percentuale automatica, e default group=state Project. Test su GLPI reale NON ESEGUITO. Verificare contatori, mapping, tre trascinamenti ripetuti, form e accessibilità.

## 0.8.1-dev.11 — Regression QA (26/10/2026)
User screenshot of dev.10 shows Project percent grouping and inability to drag Project in All. Source-level fix prepared, GLPI LIVE NOT TESTED. Required checks: Project native status after old group=progress URL; All with three mappings and with partial/missing mappings; Project + Independent DnD, CSRF rotation, ACL, date_mod and instant counters; real field types for two datetime warning columns and full backup/restore prior to GLPI timestamps migration. Fixture/CI results must be verified against exact SHA; do not equate them to live acceptance.


## 27/10/2026 — CI dev.11, test Chromium corretto
Run 40362469715: FAIL nei test Chromium dopo il PASS delle suite PHP. La fixture genera anche ProjectTask con projectstates_id=0, aggiungendo una colonna senza stato alle quattro configurate. Test aggiornato per verificare cinque colonne e non quattro. La nuova CI e il collaudo GLPI reale sono da verificare; nessuna ZIP dev.11 pubblicata al momento del fix.

## CI dev.11 — 27/10/2026 packaging gate
Run GitHub Actions #40492822635 on source 63b28cc: PHP tests PASS, Chromium tests PASS; build/package FAIL because ten mandatory manuals lacked 0.8.1-dev.11. New candidate aligns the manuals and makes the early documentation gate use the same version-document list as the final ZIP checker. Until a new Actions run completes, ZIP dev.11 is NOT published and GLPI live remains NOT TESTED. No deployment, DB migration or Main change.

## CI 27/10/2026 — regression packaging test fix
Run #40507437883 failed in the newly added regression: the fixture used historical `0.8.1-dev.10`, which includes the substring `0.8.1-dev.1`, so the presence-check correctly did not report it missing. Test fixture now uses `0.8.0`, which does not contain the candidate version. No production code or GLPI database change. Full CI and ZIP publication still require new PASS.
